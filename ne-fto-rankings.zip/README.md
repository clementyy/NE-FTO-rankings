# New England FTO Rankings (React + Tailwind + Google Sheets)

Beautiful, mobile-first rankings site for FTO in New England. Pulls data from Google Sheets (API v4) or uses a mock fallback.

## Quick Start

1) Install deps:
```bash
npm i
```

2) Create `.env` from the example and fill in your Google Sheets info:
```bash
cp .env.example .env
# then edit .env
```

Required variables:
- `VITE_SHEETS_API_KEY`: Your Google API key with Sheets API enabled.
- `VITE_SHEET_ID`: The spreadsheet ID (the long string in the URL).
- `VITE_SHEET_NAME`: The sheet tab name, e.g. `Rankings`.
- `VITE_RANGE`: (optional) Range like `A1:F`, defaults to `A1:F`.

3) Run locally:
```bash
npm run dev
```

4) Build for production:
```bash
npm run build && npm run preview
```

### Google Sheet Format
Put a header row like:
```
Rank | Name | Average | Single | State | WCAID
```
Then rows of data.

### Deploy
- **Vercel** or **Netlify**: push to GitHub and import the repo. Add the `.env` values as environment variables.
- The app gracefully falls back to mock data if the API call fails (so you can see the UI immediately).

### Notes
- Light/Dark mode toggle in the header.
- Sort by any column.
- Filter by New England states (MA, NH, ME, VT, RI, CT).
- Top 3 are highlighted with medal badges.
