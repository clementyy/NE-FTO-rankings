import React, { useMemo } from 'react'

function Medal({ place }) {
  const label = place === 1 ? '🥇' : place === 2 ? '🥈' : '🥉'
  return <span className="text-2xl">{label}</span>
}

export default function TopCards({ rows, loading }) {
  const top3 = useMemo(() => rows.slice(0, 3), [rows])

  if (loading) {
    return (
      <section className="grid md:grid-cols-3 gap-4">
        {[0,1,2].map(i => (
          <div key={i} className="card p-6 h-28 animate-pulse bg-gray-100/60 dark:bg-gray-800/60" />
        ))}
      </section>
    )
  }

  return (
    <section className="grid md:grid-cols-3 gap-4">
      {top3.map((r, i) => (
        <div key={i} className="card p-6 flex items-center justify-between">
          <div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Rank #{i+1} — {r.State}</div>
            <div className="text-lg font-semibold">{r.Name}</div>
            <div className="text-sm">Avg: <span className="font-medium">{r.Average}</span> • Single: <span className="font-medium">{r.Single}</span></div>
          </div>
          <Medal place={i+1} />
        </div>
      ))}
    </section>
  )
}
