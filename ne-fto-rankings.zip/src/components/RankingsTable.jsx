import React from 'react'

export default function RankingsTable({ rows, onSort, sortBy, sortDir }) {
  const header = [
    { key: 'Rank', label: '#' },
    { key: 'Name', label: 'Name' },
    { key: 'Average', label: 'Average' },
    { key: 'Single', label: 'Single' },
    { key: 'State', label: 'State' },
    { key: 'WCAID', label: 'WCA ID' },
  ]

  const caret = (key) => sortBy === key ? (sortDir === 'asc' ? '▲' : '▼') : ''

  return (
    <div className="overflow-x-auto">
      <table className="table">
        <thead className="thead">
          <tr>
            {header.map(h => (
              <th key={h.key} className="th cursor-pointer select-none" onClick={() => onSort(h.key)}>
                <span className="inline-flex items-center gap-1">{h.label} <span className="opacity-70">{caret(h.key)}</span></span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, idx) => (
            <tr key={idx} className="row">
              <td className="td">{r.Rank || idx + 1}</td>
              <td className="td">{r.Name}</td>
              <td className="td font-semibold">{r.Average}</td>
              <td className="td">{r.Single}</td>
              <td className="td">{r.State}</td>
              <td className="td">{r.WCAID || '-'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
