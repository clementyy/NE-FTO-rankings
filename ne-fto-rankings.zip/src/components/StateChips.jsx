import React from 'react'

export default function StateChips({ states, active, onChange }) {
  return (
    <div className="flex flex-wrap gap-2">
      <button
        className={`chip ${active === 'ALL' ? 'active' : ''}`}
        onClick={() => onChange('ALL')}
      >
        All
      </button>
      {states.map(s => (
        <button
          key={s}
          className={`chip ${active === s ? 'active' : ''}`}
          onClick={() => onChange(s)}
        >
          {s}
        </button>
      ))}
    </div>
  )
}
