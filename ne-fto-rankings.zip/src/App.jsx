import React, { useEffect, useMemo, useState } from 'react'
import { fetchSheetData } from './lib/sheets'
import ThemeToggle from './components/ThemeToggle'
import StateChips from './components/StateChips'
import TopCards from './components/TopCards'
import RankingsTable from './components/RankingsTable'

const STATES = ['MA','NH','ME','VT','RI','CT']

export default function App() {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [stateFilter, setStateFilter] = useState('ALL')
  const [sortBy, setSortBy] = useState('Average')
  const [sortDir, setSortDir] = useState('asc')

  useEffect(() => {
    (async () => {
      try {
        const rows = await fetchSheetData()
        setData(rows)
      } catch (e) {
        setError(e?.message || 'Failed to fetch data')
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  const filtered = useMemo(() => {
    const rows = stateFilter === 'ALL'
      ? data
      : data.filter(r => r.State === stateFilter)
    const sorted = [...rows].sort((a,b) => {
      const dir = sortDir === 'asc' ? 1 : -1
      const coerce = (v) => {
        if (sortBy === 'Name' || sortBy === 'State' || sortBy === 'WCAID') return (v||'').toString().toLowerCase()
        const num = parseFloat(v)
        return isNaN(num) ? Number.POSITIVE_INFINITY : num
      }
      const va = coerce(a[sortBy])
      const vb = coerce(b[sortBy])
      if (va < vb) return -1 * dir
      if (va > vb) return 1 * dir
      return 0
    })
    return sorted
  }, [data, stateFilter, sortBy, sortDir])

  const onSort = (key) => {
    if (sortBy === key) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    } else {
      setSortBy(key)
      setSortDir('asc')
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 dark:bg-gray-900 dark:text-gray-100">
      <header className="sticky top-0 z-10 backdrop-blur bg-white/70 dark:bg-gray-900/60 border-b border-gray-200/60 dark:border-gray-800">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-blue-500 via-indigo-500 to-violet-600"></div>
            <div>
              <h1 className="text-lg font-bold">New England FTO Rankings</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">The definitive unofficial FTO ladder</p>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        <section className="card p-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
            <div>
              <h2 className="text-2xl font-semibold">Current Rankings</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">Filter by state, sort by any column, and explore top singles/averages.</p>
            </div>
            <div className="flex items-center gap-3">
              <label className="text-sm">Sort by</label>
              <select
                className="btn"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
              >
                <option>Name</option>
                <option>Average</option>
                <option>Single</option>
                <option>State</option>
              </select>
              <button className="btn" onClick={() => setSortDir(d => d === 'asc' ? 'desc' : 'asc')}>
                {sortDir === 'asc' ? '↑ Asc' : '↓ Desc'}
              </button>
            </div>
          </div>

          <div className="mt-4">
            <StateChips
              states={STATES}
              active={stateFilter}
              onChange={setStateFilter}
            />
          </div>
        </section>

        <TopCards rows={filtered} loading={loading} />

        <section className="card p-2 overflow-hidden">
          {loading ? (
            <div className="p-6 text-sm text-gray-500 dark:text-gray-400">Loading rankings…</div>
          ) : (
            <RankingsTable rows={filtered} onSort={onSort} sortBy={sortBy} sortDir={sortDir} />
          )}
          {error && <div className="p-4 text-red-500 text-sm border-t border-red-200 dark:border-red-800">{error}</div>}
        </section>
      </main>

      <footer className="max-w-6xl mx-auto px-4 py-10 text-xs text-gray-500 dark:text-gray-400">
        Built with ♥ for New England cubers — FTO forever.
      </footer>
    </div>
  )
}
